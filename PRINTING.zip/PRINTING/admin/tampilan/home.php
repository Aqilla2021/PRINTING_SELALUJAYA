        <h4>Data Admin</h4>
        <br />
        
        
    
        <!-- Trigger the modal with a button -->
        <button type="button" class="btn btn-primary btn-md mr-2" data-toggle="modal" data-target="#myModal">
            <i class="fa fa-plus"></i> Tambah Data</button>
        <div class="clearfix"></div>
        <br />
        <!-- view barang -->
        <div class="card card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-sm" id="example1">
                    <thead>
                        <tr style="background:#DFF0D8;color:#333;">
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>No Hp</th>
                            <th>Foto</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
            $no =1;
            $admin=$koneksi->query("SELECT * FROM admin  ");
            while($m=mysqli_fetch_array($admin)){
                   
          ?> 
                        <tr>
                            <td><?= $no;?></td>
                            <td><?= $m['nama'];?></td>
                            <td><?= $m['username'];?></td>
                            <td><?= $m['nohp'];?></td>
                            <td><img src="../images/admin/<?= $m['gambar'];?>" height="200px" width="200px"></td>
                            <td>

                                <a href="" data-toggle="modal" data-target="#myEdit<?= $m['id_admin'];?>"><button
                                        class="btn btn-warning btn-xs">Edit</button></a>
                                <a href="?page=page/admin/hapus&id=<?= $m['id_admin'];?>"
                                    onclick="javascript:return confirm('Yakin hapus data ini ?');"><button
                                        class="btn btn-danger btn-xs">Hapus</button></a>
                                <div id="myEdit<?= $m['id_admin'];?>" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style=" border-radius:0px;">
                    <div class="modal-header" style="background:#285c64;color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-check"></i> Edit Data</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $m['id_admin'];?>">
                        <div class="modal-body">
                            <table class="table table-striped bordered">
                            
                                
                                <tr>
                                    <td>Nama</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="nama" value="<?= $m['nama'];?>"></td>
                                </tr>
                                <tr>
                                    <td>Username</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="username" value="<?= $m['username'];?>"></td>
                                </tr>
                                <tr>
                                    <td>Password</td>
                                    <td><input type="password" placeholder="" required class="form-control"
                                            name="password" value="<?= $m['password'];?>"></td>
                                </tr>
                                <tr>
                                    <td>No Hp</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="nohp" value="<?= $m['nohp'];?>"></td>
                                </tr>
                                <tr>
                                    <td>Foto</td>
                                    <td>
                                        <img src="../images/admin/<?= $m['gambar'];?>" height="200px" width="200px"><input type="file" placeholder=""  class="form-control"
                                            name="gambar" ></td>
                                </tr>
                               
                                
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="submit"  name="edit" class="btn btn-primary"><i class="fa fa-plus"></i> Simpan
                                Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
                        </tr>
                        <?php 
                            $no++; 
                         }
                    ?>
                    </tbody>
                                   </table>
            </div>
        </div>
        <!-- end view barang -->
        <!-- tambah barang MODALS-->
        <!-- Modal -->

        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style=" border-radius:0px;">
                    <div class="modal-header" style="background:#285c64;color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-plus"></i> Tambah Data</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                            <table class="table table-striped bordered">
                            
                                
                                 
                                <tr>
                                    <td>Nama</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="nama"></td>
                                </tr>
                                <tr>
                                    <td>Username</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="username"></td>
                                </tr>
                                <tr>
                                    <td>Password</td>
                                    <td><input type="password" placeholder="" required class="form-control"
                                            name="password" ></td>
                                </tr>
                                <tr>
                                    <td>No Hp</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="nohp" ></td>
                                </tr>
                                <tr>
                                    <td>Foto</td>
                                    <td>
                                        <input type="file" placeholder="" required class="form-control"
                                            name="gambar" ></td>
                                </tr>
                               
                                
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="submit"  name="simpan" class="btn btn-primary"><i class="fa fa-plus"></i> Simpan
                                Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <?php

    if (isset ($_POST['simpan'])){
        $file_name = $_FILES['gambar']['name'];
        $tmp_name = $_FILES['gambar']['tmp_name'];
        $nama=addslashes($_POST['nama']);

$nohp = $_POST['nohp'];
        $username=addslashes($_POST['username']);
        $password=addslashes($_POST['password']);

        $query_simpan =$koneksi->query( "INSERT INTO admin SET 
        nama='$nama',
        username='$username',
        nohp='$nohp',
        password='$password',
        gambar='$file_name'
        ");
        move_uploaded_file($tmp_name, "../images/admin/".$file_name);


    if ($query_simpan) {
      echo"<script>alert('Data  Berhasil di tambah !!!'); window.location = '?page=page/admin/index'</script>";
      }else{
      echo"<script>alert('Data  Gagal di Tambah !!!'); window.location = '?page=page/admin/index'</script>";
    }
}elseif(isset($_POST['edit'])){

     $gambar   = $_FILES['gambar']['name'];
  $pp = $_POST['password'];
  if (empty($gambar) && empty($pp)){
    $koneksi->query("UPDATE admin SET 
                    nama     = '$_POST[nama]',
                    username = '$_POST[username]',
                    nohp    = '$_POST[nohp]'
                    WHERE id_admin = '$_POST[id]'");
}elseif(empty($gambar) && !empty($pp)){
    $koneksi->query("UPDATE admin SET 
                    nama     = '$_POST[nama]',
                    username = '$_POST[username]',
                    nohp    = '$_POST[nohp]',
                    password = '$pp'
                    WHERE id_admin = '$_POST[id]'");
    }elseif(!empty($gambar) && empty($pp)){


    $hapus= $koneksi->query("select * from admin where id_admin='$_POST[id]'");
    $tanggal_gambar=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_gambar['gambar'];
    $hapus_gambar="../images/admin/$lokasi";
    unlink($hapus_gambar);
    move_uploaded_file($_FILES['gambar']['tmp_name'],'../images/admin/'.$gambar);
    $koneksi->query("UPDATE admin SET nama     = '$_POST[nama]',
                    username     = '$_POST[username]',
                    nohp    = '$_POST[nohp]',
                    gambar  = '$gambar'
                    WHERE id_admin= '$_POST[id]'");
  }elseif(!empty($gambar) && !empty($pp)){


    $hapus= $koneksi->query("select * from admin where id_admin='$_POST[id]'");
    $tanggal_gambar=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_gambar['gambar'];
    $hapus_gambar="../images/admin/$lokasi";
    unlink($hapus_gambar);
    move_uploaded_file($_FILES['gambar']['tmp_name'],'../images/admin/'.$gambar);
    $koneksi->query("UPDATE admin SET nama     = '$_POST[nama]',
                    username     = '$_POST[username]',
                    nohp    = '$_POST[nohp]',
                    password = '$pp',
                    gambar  = '$gambar'
                    WHERE id_admin= '$_POST[id]'");
  }
echo"<script>alert('Data Berhasil di Ubah!!!'); window.location = '?page=page/admin/index'</script>";
    

}
?>