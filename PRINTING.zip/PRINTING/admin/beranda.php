<?php 

error_reporting(0);
	session_start();

	if(!empty($_SESSION['id'])){
		include '../config/config.php';
		include '../config/waktu.php';
		include '../config/tgl_indo.php';
		
		//  admin
			include 'tampilan/header.php';
			include 'tampilan/sidebar.php';
			  if (isset($_GET['page'])) {
                $page = $_GET['page'];
                $file = "$page.php";

                if (!file_exists($file)) {
                    include ("tampilan/home.php");
                }else{
                    include ("$page.php");
                }
            }else{
                include ("tampilan/home.php");
            }
			include 'tampilan/footer.php';
		// end admin


	}else{
		echo '<script>window.location="index.php";</script>';
		exit;
	}
?>