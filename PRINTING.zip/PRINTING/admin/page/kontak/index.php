<?php $kontak=$koneksi->query("SELECT * FROM kontak WHERE id_kontak='1'  ");
            $m=mysqli_fetch_array($kontak);?><h4>Pengaturan Web</h4>
<br>

<div class="card">
    <div class="card-body">
        <form method="post" action="" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md 6">
                    <div class="form-group">
                        <label for="">Nama </label>
                        <input class="form-control" name="nama" type="text" value="<?php echo $m['nama'];?>"
                                    placeholder="">
                    </div>
                    <div class="form-group">
                        <label for="">Alamat </label>
                        <input class="form-control" name="alamat" type="text" value="<?php echo $m['alamat'];?>"
                                    placeholder=" ">
                    </div>
                </div>
                <div class="col-md 6">
                    <div class="form-group">
                        <label for="">TLP</label>
                        <input class="form-control"  type="text" name="tlp" value="<?php echo $m['tlp'];?>">
                                    
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input class="form-control"  type="email" name="email" value="<?php echo $m['email'];?>" >
                    </div>
                </div>
               
            </div>
             <div class="row">
                <div class="col-md 6">
                    <div class="form-group">
                        <label for="">No Rekening </label>
                        <input class="form-control" name="norek" type="text" value="<?php echo $m['norek'];?>"
                                    placeholder="">
                    </div>
                    <div class="form-group">
                        <label for="">Bank </label>
                        <input class="form-control" name="bank" type="text" value="<?php echo $m['bank'];?>"
                                    placeholder=" ">
                    </div>
                </div>
                <div class="col-md 6">
                    <div class="form-group">
                        <label for="">Rekening Atas Nama</label>
                        <input class="form-control"  type="text" name="atasnama" value="<?php echo $m['atasnama'];?>">
                                    
                    </div>
                    <div class="form-group">
                        <label for="">Tentang Kami</label>
                        <textarea class="form-control" name="tentangkami"><?php echo $m['tentangkami'];?></textarea>
                        
                    </div>
                </div>
               
            </div>
            <div class="row">
            
                <div class="col-md 6">
                   
                <div class="row">
                 <div class="col-md 6">
                    <table>
                        <tr>
                            <td><label for="">Logo</label></td>
                            <td> <img src="../images/logo/<?= $m['logo'];?>" width="300px" height="300px"></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td colspan="2"><input class="form-contro" type="file" name="logo" ></td>
                           
                        </tr>
                        <tr>
                            <td><br></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td><label for="">Maps</label></td>
                            <td colspan="2"> <iframe src="<?= $m['maps'];?>" width="600px" height="300px"></iframe></td>
                            <td width="300px"></td>
                        </tr>
                        <tr>
                           <td></td>
                            <td colspan="2"><textarea class="form-control" type="text" name="maps" ><?= $m['maps'];?></textarea></td>
                           
                        </tr><tr>
                            <td><br></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </table>
                   
                </div></div>
            <button id="tombol-simpan" name="edit" class="btn btn-primary"><i class="fas fa-edit"></i> Update Data</button>
        </form>
    </div>
</div>
<?php if(isset($_POST['edit'])){

     $logo   = $_FILES['logo']['name'];
  $maps = $_POST['maps'];
  if (empty($logo)){
    $koneksi->query("UPDATE kontak SET 
                    nama     = '$_POST[nama]',
                    maps = '$maps',
                    tlp    = '$_POST[tlp]',
                    email    = '$_POST[email]',
                    norek    = '$_POST[norek]',
                    bank    = '$_POST[bank]',
                    atasnama    = '$_POST[atasnama]',
                    tentangkami    = '$_POST[tentangkami]',
                    alamat    = '$_POST[alamat]'
                    WHERE id_kontak = '1'");
 }else{


    $hapus= $koneksi->query("select * from kontak where id_kontak='1'");
    $tanggal_logo=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_logo['logo'];
    $hapus_logo="../images/logo/$lokasi";
    unlink($hapus_logo);
    move_uploaded_file($_FILES['logo']['tmp_name'],'../images/logo/'.$logo);
    $koneksi->query("UPDATE kontak SET 
                    nama     = '$_POST[nama]',
                    maps = '$maps',
                    tlp    = '$_POST[tlp]',
                    email    = '$_POST[email]',
                    norek    = '$_POST[norek]',
                    bank    = '$_POST[bank]',
                    atasnama    = '$_POST[atasnama]',
                    tentangkami    = '$_POST[tentangkami]',
                    alamat    = '$_POST[alamat]',
                    logo  = '$logo'
                    WHERE id_kontak= '1'");
  }
echo"<script>alert('Data Berhasil di Ubah!!!'); window.location = '?page=page/kontak/index'</script>";
    

}
?>