        <h4>Data slider</h4>
        <br />
        
        
	
        <!-- Trigger the modal with a button -->
        <button type="button" class="btn btn-primary btn-md mr-2" data-toggle="modal" data-target="#myModal">
            <i class="fa fa-plus"></i> Tambah Data</button>
        <div class="clearfix"></div>
        <br />
        <!-- view barang -->
        <div class="card card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-sm" id="example1">
                    <thead>
                        <tr style="background:#DFF0D8;color:#333;">
                            <th>No.</th>
                            <th>Slider</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
            $no =1;
            $slider=$koneksi->query("SELECT * FROM slider   ");
            while($m=mysqli_fetch_array($slider)){
                   
          ?> 
                        <tr>
                            <td><?= $no;?></td>
                            <td><img src="../images/slider/<?= $m['slider'];?>" height="200px" width="200px"></td>
                            <td>

                                <a href="" data-toggle="modal" data-target="#myEdit<?= $m['id_slider'];?>"><button
                                        class="btn btn-warning btn-xs">Edit</button></a>
                                <a href="?page=page/slider/hapus&id=<?= $m['id_slider'];?>"
                                    onclick="javascript:return confirm('Yakin hapus data ini ?');"><button
                                        class="btn btn-danger btn-xs">Hapus</button></a>
                                <div id="myEdit<?= $m['id_slider'];?>" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style=" border-radius:0px;">
                    <div class="modal-header" style="background:#285c64;color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-check"></i> Edit Data</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $m['id_slider'];?>">
                        <div class="modal-body">
                            <table class="table table-striped bordered">
                            
                                
                               
                                
                                <tr>
                                    <td>slider</td>
                                    <td>
                                        <img src="../images/slider/<?= $m['slider'];?>" height="200px" width="200px"><input type="file" placeholder=""  class="form-control"
                                            name="slider" ></td>
                                </tr>
                               
                                
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="submit"  name="edit" class="btn btn-primary"><i class="fa fa-plus"></i> Simpan
                                Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
                        </tr>
                        <?php 
							$no++; 
						 }
					?>
                    </tbody>
                                   </table>
            </div>
        </div>
        <!-- end view barang -->
        <!-- tambah barang MODALS-->
        <!-- Modal -->

        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style=" border-radius:0px;">
                    <div class="modal-header" style="background:#285c64;color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-plus"></i> Tambah Data</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                            <table class="table table-striped bordered">
                            
                                
                                 
                                <tr>
                                    <td>slider</td>
                                    <td>
                                        <input type="file" placeholder="" required class="form-control"
                                            name="slider" ></td>
                                </tr>
                               
                                
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="submit"  name="simpan" class="btn btn-primary"><i class="fa fa-plus"></i> Simpan
                                Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <?php

    if (isset ($_POST['simpan'])){
        $file_name = $_FILES['slider']['name'];
        $tmp_name = $_FILES['slider']['tmp_name'];
        


        $query_simpan =$koneksi->query( "INSERT INTO slider SET 
        slider='$file_name'
        ");
        move_uploaded_file($tmp_name, "../images/slider/".$file_name);


    if ($query_simpan) {
      echo"<script>alert('Data  Berhasil di tambah !!!'); window.location = '?page=page/slider/index'</script>";
      }else{
      echo"<script>alert('Data  Gagal di Tambah !!!'); window.location = '?page=page/slider/index'</script>";
    }
}elseif(isset($_POST['edit'])){

     $slider   = $_FILES['slider']['name'];
  
    $hapus= $koneksi->query("select * from slider where id_slider='$_POST[id]'");
    $tanggal_slider=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_slider['slider'];
    $hapus_slider="../images/slider/$lokasi";
    unlink($hapus_slider);
    move_uploaded_file($_FILES['slider']['tmp_name'],'../images/slider/'.$slider);
    $koneksi->query("UPDATE slider SET 
                    slider  = '$slider'
                    WHERE id_slider= '$_POST[id]'");
 
echo"<script>alert('Data Berhasil di Ubah!!!'); window.location = '?page=page/slider/index'</script>";
    

}
?>