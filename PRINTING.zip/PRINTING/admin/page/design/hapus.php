<?php 
   $hapus= $koneksi->query("select*from design where id_design='$_GET[id]'");
    // memilih design1 untuk dihapus
    $nama_design1=mysqli_fetch_array($hapus);
    // nama field design1
    $lokasi=$nama_design1['design'];
    // alamat tempat design1
    $hapus_design1="../images/design/$lokasi";
    // script delete design1 dari folder
    unlink($hapus_design1);
     $koneksi->query("DELETE FROM design WHERE id_design='$_GET[id]'");
 echo"<script>alert('Data Berhasil di Hapus !!!'); window.location = '?page=page/design/index'</script>";
?>