        <h4>Data design</h4>
        <br />
        
        
	
        <!-- Trigger the modal with a button -->
        <button type="button" class="btn btn-primary btn-md mr-2" data-toggle="modal" data-target="#myModal">
            <i class="fa fa-plus"></i> Tambah Data</button>
        <div class="clearfix"></div>
        <br />
        <!-- view barang -->
        <div class="card card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-sm" id="example1">
                    <thead>
                        <tr style="background:#DFF0D8;color:#333;">
                            <th>No.</th>
                            <th>judul</th>
                            <th>Jenis Percetakan</th>
                            <th>design</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
            $no =1;
            $design=$koneksi->query("SELECT * FROM design as d, jenis_percetakan as j where d.id_jenis=j.id_jenis  ");
            while($m=mysqli_fetch_array($design)){
                   
          ?> 
                        <tr>
                            <td><?= $no;?></td>
                            <td><?= $m['judul'];?></td>
                            <td><?= $m['namajenis'];?></td>
                            <td><img src="../images/design/<?= $m['design'];?>" height="200px" width="200px"></td>
                            <td>

                                <a href="" data-toggle="modal" data-target="#myEdit<?= $m['id_design'];?>"><button
                                        class="btn btn-warning btn-xs">Edit</button></a>
                                <a href="?page=page/design/hapus&id=<?= $m['id_design'];?>"
                                    onclick="javascript:return confirm('Yakin hapus data ini ?');"><button
                                        class="btn btn-danger btn-xs">Hapus</button></a>
                                <div id="myEdit<?= $m['id_design'];?>" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style=" border-radius:0px;">
                    <div class="modal-header" style="background:#285c64;color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-check"></i> Edit Data</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $m['id_design'];?>">
                        <div class="modal-body">
                            <table class="table table-striped bordered">
                            
                                
                                <tr>
                                    <td>Judul</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="judul" value="<?= $m['judul'];?>"></td>
                                </tr>
                                <tr>
                                    <td>Jenis Percetakan</td>
                                    <td><select name="id_jenis" class="form-control">
                                        <option value="<?= $m['id_jenis'];?>"><?= $m['namajenis'];?></option>
                                        <?php $designa=$koneksi->query("SELECT * FROM jenis_percetakan   ");
            while($ma=mysqli_fetch_array($designa)){
                    ?><option value="<?= $ma['id_jenis'];?>"><?= $ma['namajenis'];?></option>
                <?php }?>
                                    </select></td>
                                </tr>
                                
                                <tr>
                                    <td>Design</td>
                                    <td>
                                        <img src="../images/design/<?= $m['design'];?>" height="200px" width="200px"><input type="file" placeholder=""  class="form-control"
                                            name="design" ></td>
                                </tr>
                               
                                
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="submit"  name="edit" class="btn btn-primary"><i class="fa fa-plus"></i> Simpan
                                Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
                        </tr>
                        <?php 
							$no++; 
						 }
					?>
                    </tbody>
                                   </table>
            </div>
        </div>
        <!-- end view barang -->
        <!-- tambah barang MODALS-->
        <!-- Modal -->

        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style=" border-radius:0px;">
                    <div class="modal-header" style="background:#285c64;color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-plus"></i> Tambah Data</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                            <table class="table table-striped bordered">
                            
                                
                                 
                                <tr>
                                    <td>Judul</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="judul"></td>
                                </tr>
                                <tr>
                                    <td>Jenis Percetakan</td>
                                    <td><select name="id_jenis" class="form-control">
                                        <option >Pilih</option>
                                        <?php $designa=$koneksi->query("SELECT * FROM jenis_percetakan   ");
            while($ma=mysqli_fetch_array($designa)){
                    ?><option value="<?= $ma['id_jenis'];?>"><?= $ma['namajenis'];?></option>
                <?php }?>
                                    </select></td>
                                </tr>
                                <tr>
                                    <td>Design</td>
                                    <td>
                                        <input type="file" placeholder="" required class="form-control"
                                            name="design" ></td>
                                </tr>
                               
                                
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="submit"  name="simpan" class="btn btn-primary"><i class="fa fa-plus"></i> Simpan
                                Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <?php

    if (isset ($_POST['simpan'])){
        $file_name = $_FILES['design']['name'];
        $tmp_name = $_FILES['design']['tmp_name'];
        $judul=addslashes($_POST['judul']);
        $id_jenis=addslashes($_POST['id_jenis']);


        $query_simpan =$koneksi->query( "INSERT INTO design SET 
        judul='$judul',
        id_jenis='$id_jenis',
        design='$file_name'
        ");
        move_uploaded_file($tmp_name, "../images/design/".$file_name);


    if ($query_simpan) {
      echo"<script>alert('Data  Berhasil di tambah !!!'); window.location = '?page=page/design/index'</script>";
      }else{
      echo"<script>alert('Data  Gagal di Tambah !!!'); window.location = '?page=page/design/index'</script>";
    }
}elseif(isset($_POST['edit'])){

        $id_jenis=addslashes($_POST['id_jenis']);
     $design   = $_FILES['design']['name'];
  if (empty($design)){
    $koneksi->query("UPDATE design SET 
        id_jenis='$id_jenis',
                    judul     = '$_POST[judul]'
                    WHERE id_design = '$_POST[id]'");

    }else{


    $hapus= $koneksi->query("select * from design where id_design='$_POST[id]'");
    $tanggal_design=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_design['design'];
    $hapus_design="../images/design/$lokasi";
    unlink($hapus_design);
    move_uploaded_file($_FILES['design']['tmp_name'],'../images/design/'.$design);
    $koneksi->query("UPDATE design SET judul     = '$_POST[judul]',
        id_jenis='$id_jenis',
                    design  = '$design'
                    WHERE id_design= '$_POST[id]'");}
 
echo"<script>alert('Data Berhasil di Ubah!!!'); window.location = '?page=page/design/index'</script>";
    

}
?>