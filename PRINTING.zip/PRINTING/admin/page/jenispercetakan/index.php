        <h4>Data Jenis Percetakan</h4>
        <br />
        
        
	
        <!-- Trigger the modal with a button -->
        <button type="button" class="btn btn-primary btn-md mr-2" data-toggle="modal" data-target="#myModal">
            <i class="fa fa-plus"></i> Tambah Data</button>
        <div class="clearfix"></div>
        <br />
        <!-- view barang -->
        <div class="card card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-sm" id="example1">
                    <thead>
                        <tr style="background:#DFF0D8;color:#333;">
                            <th>No.</th>
                            <th>Foto</th>
                            <th>Nama Jenis Percetakan</th>
                            <th>Harga</th>
                            <th>Ukuran</th>
                            <th>Satuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
            $no =1;
            $admin=$koneksi->query("SELECT * FROM jenis_percetakan  ");
            while($m=mysqli_fetch_array($admin)){
                   
          ?> 
                        <tr>
                            <td><?= $no;?></td>
                            <td><img src="../images/jenis/<?= $m['foto'];?>" width="100px" height="100px"></td>
                            <td><?= $m['namajenis'];?></td>
                            <td><?= $m['harga'];?></td>
                            <td><?= $m['ukuran'];?></td>
                            <td><?= $m['satuan'];?></td>
                            <td>

                                <a href="" data-toggle="modal" data-target="#myEdit<?= $m['id_jenis'];?>"><button
                                        class="btn btn-warning btn-xs">Edit</button></a>
                                <a href="?page=page/jenispercetakan/hapus&id=<?= $m['id_jenis'];?>"
                                    onclick="javascript:return confirm('Yakin hapus data ini ?');"><button
                                        class="btn btn-danger btn-xs">Hapus</button></a>
                                <div id="myEdit<?= $m['id_jenis'];?>" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style=" border-radius:0px;">
                    <div class="modal-header" style="background:#285c64;color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-plus"></i> Edit Data</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $m['id_jenis'];?>">
                        <div class="modal-body">
                            <table class="table table-striped bordered">
                            
                                
                                <tr>
                                    <td>Nama Jenis Percetakan</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="namajenis" value="<?= $m['namajenis'];?>"></td>
                                </tr>
                                <tr>
                                    <td>Harga</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="harga" value="<?= $m['harga'];?>"></td>
                                </tr>
                                <tr>
                                    <td>Ukuran</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="ukuran" value="<?= $m['ukuran'];?>"></td>
                                </tr>
                                <tr>
                                    <td>Satuan</td>
                                    <td><select name="satuan" class="form-control" type="text">
                                        <option value="<?= $m['satuan'];?>"><?= $m['satuan'];?></option>
                                        <option value="Meter">Meter</option>
                                        <option value="cm">cm</option>
                                        <option value="Lembar">Lembar</option>
                                        <option value="Pcs">Pcs</option>
                                        <option value="Lusin">Lusin</option>
                                    </select></td>
                                </tr>
                               <tr>
                                    <td>Foto</td>
                                    <td><img src="../images/jenis/<?= $m['foto'];?>" width="100px" height="100px"><input type="file" placeholder="" required class="form-control"
                                            name="foto"></td>
                                </tr>
                                
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="submit"  name="edit" class="btn btn-primary"><i class="fa fa-plus"></i> Simpan
                                Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
                        </tr>
                        <?php 
							$no++; 
						 }
					?>
                    </tbody>
                                   </table>
            </div>
        </div>
        <!-- end view barang -->
        <!-- tambah barang MODALS-->
        <!-- Modal -->

        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content" style=" border-radius:0px;">
                    <div class="modal-header" style="background:#285c64;color:#fff;">
                        <h5 class="modal-title"><i class="fa fa-plus"></i> Tambah Data</h5>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                            <table class="table table-striped bordered">
                            
                                
                                <tr>
                                    <td>Nama Jenis Percetakan</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="namajenis"></td>
                                </tr>
                                <tr>
                                    <td>Harga</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="harga"></td>
                                </tr>
                                <tr>
                                    <td>Ukuran</td>
                                    <td><input type="text" placeholder="" required class="form-control"
                                            name="ukuran"></td>
                                </tr>
                                <tr>
                                    <td>Satuan</td>
                                    <td><select name="satuan" class="form-control" type="text">
                                        <option>Pilih</option>
                                        <option value="Meter">Meter</option>
                                        <option value="cm">cm</option>
                                        <option value="Lembar">Lembar</option>
                                        <option value="Pcs">Pcs</option>
                                        <option value="Lusin">Lusin</option>
                                    </select></td>
                                </tr>
                               
                                <tr>
                                    <td>Foto</td>
                                    <td><input type="file" placeholder="" required class="form-control"
                                            name="foto"></td>
                                </tr>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="submit"  name="simpan" class="btn btn-primary"><i class="fa fa-plus"></i> Simpan
                                Data</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
        <?php

    if (isset ($_POST['simpan'])){
        
        $nama=addslashes($_POST['namajenis']);
$file_name = $_FILES['foto']['name'];
        $tmp_name = $_FILES['foto']['tmp_name'];
$harga = $_POST['harga'];
        $satuan=addslashes($_POST['satuan']);
        $ukuran=addslashes($_POST['ukuran']);
       
        $query_simpan =$koneksi->query( "INSERT INTO jenis_percetakan SET 
        namajenis='$nama',
        harga='$harga',
        ukuran='$ukuran',
        satuan='$satuan',
        foto='$file_name'
        ");
        move_uploaded_file($tmp_name, "../images/jenis/".$file_name);
        

    if ($query_simpan) {
      echo"<script>alert('Data  Berhasil di tambah !!!'); window.location = '?page=page/jenispercetakan/index'</script>";
      }else{
      echo"<script>alert('Data  Gagal di Tambah !!!'); window.location = '?page=page/jenispercetakan/index'</script>";
    }
}elseif(isset($_POST['edit'])){
    $nama=addslashes($_POST['namajenis']);

$harga = $_POST['harga'];
        $satuan=addslashes($_POST['satuan']);
        $ukuran=addslashes($_POST['ukuran']);
        $gambar   = $_FILES['foto']['name'];
       if (empty($gambar)){
        $query_simpan =$koneksi->query( "UPDATE jenis_percetakan SET 
        namajenis='$nama',
        harga='$harga',
        ukuran='$ukuran',
        satuan='$satuan' where id_jenis='$_POST[id]'
        ");
        

    if ($query_simpan) {
      echo"<script>alert('Data  Berhasil di Edit !!!'); window.location = '?page=page/jenispercetakan/index'</script>";
      }else{
      echo"<script>alert('Data  Gagal di simpan !!!'); window.location = '?page=page/jenispercetakan/index'</script>";
    }
}else{
     $hapus= $koneksi->query("select * from jenis_percetakan where id_jenis='$_POST[id]'");
    $tanggal_gambar=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_gambar['foto'];
    $hapus_gambar="../images/jenis/$lokasi";
    unlink($hapus_gambar);
    move_uploaded_file($_FILES['foto']['tmp_name'],'../images/jenis/'.$gambar);
     $query_simpan =$koneksi->query( "UPDATE jenis_percetakan SET 
        namajenis='$nama',
        harga='$harga',
        ukuran='$ukuran',
        satuan='$satuan',
        foto='$gambar' where id_jenis='$_POST[id]'
        ");
        

    if ($query_simpan) {
      echo"<script>alert('Data  Berhasil di Edit !!!'); window.location = '?page=page/jenispercetakan/index'</script>";
      }else{
      echo"<script>alert('Data  Gagal di simpan !!!'); window.location = '?page=page/jenispercetakan/index'</script>";
    }

}

}
?>