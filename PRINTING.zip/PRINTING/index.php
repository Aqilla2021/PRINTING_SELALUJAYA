<?php error_reporting(0);
session_start();
include"config/config.php";
include"config/waktu.php";
include"config/tgl_indo.php";
$kontak=$koneksi->query("SELECT * FROM kontak WHERE id_kontak='1'  ");
            $mkon=mysqli_fetch_array($kontak);?>
<!DOCTYPE html>
<html>
<?php include"tampilan/head.php";?>
<body>
  <!--header-->
	<?php 
	include"tampilan/menu.php";
     if (isset($_GET['page'])) {
                $page = $_GET['page'];
                $file = "$page.php";

                if (!file_exists($file)) {
                    include ("page/home.php");
                }else{
                    include ("$page.php");
                }
            }else{
                include ("page/home.php");
            }
            include "tampilan/footer.php";
      
    ?>
	
</body>
</html>