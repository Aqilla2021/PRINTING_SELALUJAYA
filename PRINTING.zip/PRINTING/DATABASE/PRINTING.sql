-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2023 at 07:32 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `PRINTING`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `nohp` varchar(225) NOT NULL,
  `gambar` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama`, `username`, `password`, `nohp`, `gambar`) VALUES
(1, 'admin', 'admin', 'admin', '0821223', 'banner2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `design`
--

CREATE TABLE `design` (
  `id_design` int(11) NOT NULL,
  `id_jenis` varchar(11) NOT NULL,
  `judul` varchar(225) NOT NULL,
  `design` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `design`
--

INSERT INTO `design` (`id_design`, `id_jenis`, `judul`, `design`) VALUES
(3, '4', '17 agustus ', 'WhatsApp Image 2023-08-12 at 07.49.27.jpeg'),
(5, '10', 'Cetak Foto 2x3 ', 'WhatsApp Image 2023-08-12 at 23.25.57.jpeg'),
(6, '16', 'Contoh Undangan Pernikahan 2 sisi', 'WhatsApp Image 2023-08-12 at 23.45.32.jpeg'),
(7, '14', 'Brosur Makanan ', 'WhatsApp Image 2023-08-12 at 23.34.54.jpeg'),
(8, '19', 'STIKER BRAND', 'ap.png'),
(9, '7', 'SPANDUK PROMOSI', 'pi5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_percetakan`
--

CREATE TABLE `jenis_percetakan` (
  `id_jenis` int(11) NOT NULL,
  `namajenis` varchar(225) NOT NULL,
  `harga` varchar(225) NOT NULL,
  `ukuran` varchar(225) NOT NULL,
  `satuan` varchar(225) NOT NULL,
  `foto` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_percetakan`
--

INSERT INTO `jenis_percetakan` (`id_jenis`, `namajenis`, `harga`, `ukuran`, `satuan`, `foto`) VALUES
(7, 'PRINTING SPANDUK', '15000', '1X1', 'Meter', 'flight1.jpg'),
(19, 'PRINTING STIKER', '30000', '1x1', 'Meter', 'flight2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `keritikandansaran`
--

CREATE TABLE `keritikandansaran` (
  `id_keritikan` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `subjek` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `keritikan` varchar(225) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL,
  `status` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `keritikandansaran`
--

INSERT INTO `keritikandansaran` (`id_keritikan`, `nama`, `subjek`, `email`, `keritikan`, `tgl`, `jam`, `status`) VALUES
(1, 'mus', 'kaeak', 'suherma4556@gmail.com', ' sdsd', '2023-07-11', '01:25:58', 'Baru');

-- --------------------------------------------------------

--
-- Table structure for table `kontak`
--

CREATE TABLE `kontak` (
  `id_kontak` int(11) NOT NULL,
  `norek` varchar(225) NOT NULL,
  `bank` varchar(225) NOT NULL,
  `atasnama` varchar(225) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `maps` varchar(225) NOT NULL,
  `tlp` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `logo` varchar(225) NOT NULL,
  `tentangkami` text NOT NULL,
  `alamat` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kontak`
--

INSERT INTO `kontak` (`id_kontak`, `norek`, `bank`, `atasnama`, `nama`, `maps`, `tlp`, `email`, `logo`, `tentangkami`, `alamat`) VALUES
(1, '432111', 'BCA', 'PRINTING', 'PRINTING', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3749422.23909492!2d103!3d55!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x453c569a896724fb%3A0x1409fdf86611f613!2sRussia!5e0!3m2!1sen!2sin!4v1415776049771', '054-007', 'PRINTING@gmail.com', 'pi.jpg', 'PRINTING', 'JAKARTA');

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(11) NOT NULL,
  `id_user` varchar(225) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL,
  `status` varchar(225) NOT NULL,
  `upload` varchar(225) NOT NULL,
  `jumlah` varchar(225) NOT NULL,
  `ket` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `id_user`, `tgl`, `jam`, `status`, `upload`, `jumlah`, `ket`) VALUES
(25, '1', '2023-08-16', '03:41:07', 'Selesai di Cetak', 'ap.png', '100.000', 'Sudah di Bayar');

-- --------------------------------------------------------

--
-- Table structure for table `pesanpercetakan`
--

CREATE TABLE `pesanpercetakan` (
  `id_pesanpercetakan` int(11) NOT NULL,
  `id_pesan` varchar(11) NOT NULL,
  `id_user` varchar(225) NOT NULL,
  `id_jenis` varchar(225) NOT NULL,
  `jumlah` varchar(225) NOT NULL,
  `ukuran` varchar(225) NOT NULL,
  `gambar` varchar(225) NOT NULL,
  `harga` varchar(225) NOT NULL,
  `keteranganpemesanan` text NOT NULL,
  `status` varchar(225) NOT NULL,
  `id_design` varchar(225) NOT NULL,
  `jenispesan` varchar(225) NOT NULL,
  `totalharga` varchar(225) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesanpercetakan`
--

INSERT INTO `pesanpercetakan` (`id_pesanpercetakan`, `id_pesan`, `id_user`, `id_jenis`, `jumlah`, `ukuran`, `gambar`, `harga`, `keteranganpemesanan`, `status`, `id_design`, `jenispesan`, `totalharga`, `tgl`, `jam`) VALUES
(40, '25', '1', '6', '2', '1x1', 'ap2.png', '35000', 'ddd', 'Selesai di Cetak', '', 'Costume', '70000', '2023-08-16', '03:41:07'),
(41, '25', '1', '4', '2', '2x4', '', '15000', 'ddd', 'Selesai di Cetak', '3', 'Design Teguh', '30000', '2023-08-16', '03:41:07');

-- --------------------------------------------------------

--
-- Table structure for table `pesan_temp`
--

CREATE TABLE `pesan_temp` (
  `id_pesantemp` int(11) NOT NULL,
  `id_user` varchar(11) NOT NULL,
  `id_jenis` varchar(225) NOT NULL,
  `jumlah` varchar(225) NOT NULL,
  `ukuran` varchar(225) NOT NULL,
  `satuan` varchar(225) NOT NULL,
  `gambar` varchar(225) NOT NULL,
  `harga` varchar(225) NOT NULL,
  `keteranganpemesanan` text NOT NULL,
  `status` varchar(225) NOT NULL,
  `id_design` varchar(225) NOT NULL,
  `jenispesan` varchar(225) NOT NULL,
  `totalharga` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id_slider` int(11) NOT NULL,
  `slider` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id_slider`, `slider`) VALUES
(1, 'banner.jpg'),
(2, 'banner1.jpg'),
(3, 'ap1.png'),
(4, 'pi3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `nik` varchar(225) NOT NULL,
  `alamat` varchar(225) NOT NULL,
  `foto` varchar(225) NOT NULL,
  `nohp` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `nik`, `alamat`, `foto`, `nohp`, `username`, `password`) VALUES
(1, 'aa', '123', 'ddd', '14.jpg', 'dfsdafsad', 'user', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `design`
--
ALTER TABLE `design`
  ADD PRIMARY KEY (`id_design`);

--
-- Indexes for table `jenis_percetakan`
--
ALTER TABLE `jenis_percetakan`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `keritikandansaran`
--
ALTER TABLE `keritikandansaran`
  ADD PRIMARY KEY (`id_keritikan`);

--
-- Indexes for table `kontak`
--
ALTER TABLE `kontak`
  ADD PRIMARY KEY (`id_kontak`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indexes for table `pesanpercetakan`
--
ALTER TABLE `pesanpercetakan`
  ADD PRIMARY KEY (`id_pesanpercetakan`);

--
-- Indexes for table `pesan_temp`
--
ALTER TABLE `pesan_temp`
  ADD PRIMARY KEY (`id_pesantemp`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id_slider`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `design`
--
ALTER TABLE `design`
  MODIFY `id_design` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `jenis_percetakan`
--
ALTER TABLE `jenis_percetakan`
  MODIFY `id_jenis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `keritikandansaran`
--
ALTER TABLE `keritikandansaran`
  MODIFY `id_keritikan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `kontak`
--
ALTER TABLE `kontak`
  MODIFY `id_kontak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `pesanpercetakan`
--
ALTER TABLE `pesanpercetakan`
  MODIFY `id_pesanpercetakan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `pesan_temp`
--
ALTER TABLE `pesan_temp`
  MODIFY `id_pesantemp` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id_slider` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
