	<div class="footer">
			
			<p class="footer-class">@2021 by  <a href="" target="">pRINTING</a> </p>
			
				
		</div>