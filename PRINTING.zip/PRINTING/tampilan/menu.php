<div class="header">
		<div class="header-top">
			<div class="container">	
			<div class="header-top-in">			
				<div class="logo">
					<a href=""><img src="images/logo/<?= $mkon['logo'];?>" alt=" " style="width: 200px;height: 40px;"></a>
				</div>
				<div class="header-in">
					
				</div>
				<div class="clearfix"> </div>
			</div>
			</div>
		</div>
		<div class="header-bottom">
		<div class="container">
			<div class="h_menu4">
				<a class="toggleMenu" href="#">Menu</a>
				<ul class="nav">
					<li class="active"><a href="?page=page/home"><i> </i>Home</a></li>
					<li ><a href="?page=page/design" >Design</a>
						
						</li> 						
						<li><a href="?page=page/harga" >  Harga Percetakan</a></li> 
						          
						<li><a href="?page=page/kontakkami" >Kontak Kami </a></li>
					
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div>
		</div>
		</div>
		
	</div>