<script src="js/responsiveslides.min.js"></script>
			<script>
				$(function () {
				  $("#slider1").responsiveSlides({
					auto: true,
					speed: 500,
					namespace: "callbacks",
					pager: true,
				  });
				});
			</script><div class="banner-mat">
		<div class="container">
			<div class="banner">
	
				<!-- Slideshow 4 -->
			   <div class="slider">
			<ul class="rslides" id="slider1">
				 <?php 
            $no =1;
            $slidert=$koneksi->query("SELECT * FROM slider   ");
            while($slider=mysqli_fetch_array($slidert)){
                   
          ?> 
			  <li><img src="images/slider/<?= $slider['slider'];?>" alt="">
			  </li>
			<?php }?>
			  
			</ul>
		</div>

				<div class="banner-bottom">
					<div class="banner-matter">
						
					</div>
					<div class="purchase">
					</div>
					<div class="clearfix"></div>
				</div>
			</div>				
			<!-- //slider-->
		</div>
	</div>