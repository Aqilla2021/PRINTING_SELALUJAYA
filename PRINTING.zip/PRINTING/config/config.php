<?php
$koneksi = new mysqli ("localhost","root","","PRINTING");
?>

<!-- end -->