<?php 
	include"tampilan/slider.php";?>
	<div class="container">
			<div class="content">
				<div class="content-top">
					<h3 class="future">Design Terbaru</h3>
					<div class="content-top-in">
						   <?php 
            $no =1;
            $design=$koneksi->query("SELECT * FROM design as d, jenis_percetakan as j where d.id_jenis=j.id_jenis limit 4 ");
            while($m=mysqli_fetch_array($design)){
                   
          ?> 
						<div class="col-md-3 md-col">
							<div class="col-md">
								<a href="single.html"><img  src="images/design/<?= $m['design'];?>" style="height: 250px;width: 240px;" alt="" /></a>	
								<div class="top-content">
									<h5><a href=""><?= $m['judul'];?> - <?= $m['namajenis'];?></a></h5>
								

								</div>							
							</div>
						</div>
						<?php }?>
					<div class="clearfix"></div>
					</div>
				</div>
				<!---->
				
				<!---->
				
				
			</div>
		</div>