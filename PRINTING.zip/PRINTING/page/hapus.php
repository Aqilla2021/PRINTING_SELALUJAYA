<?php 

     $koneksi->query("DELETE FROM pesanpercetakan WHERE id_pesanpercetakan='$_GET[id]'");
 echo"<script>alert('Data Berhasil di Hapus !!!'); window.location = '?page=page/pesanansaya'</script>";
?>