	<div class="container">
		<div class="account">
			<h2 class="account-in">Pesanan Saya</h2>
    <div id="angka">
            
               <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                      <div id="input">
				<table class="table table-bordered table-striped table-sm" id="example1">
                    <thead>
                        <tr style="background:#DFF0D8;color:#333;">
                            <th>No.</th>
                            <th>Foto Design</th>
                            <th>Jenis Pesan</th>
                            <th>Jenis Percetakan</th>
                            <th>Ukuran</th>
                            <th>Jumlah</th>
                            <th>Harga</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Total Harga</th>
                        </tr>
                    </thead>
                    <tbody>
                         <?php 
                        $no=0;
                            $admin=$koneksi->query("SELECT * FROM pesanpercetakan where id_user='$_SESSION[id]'  ");
            while($m=mysqli_fetch_array($admin)){
                $designa=$koneksi->query("SELECT * FROM design where id_design='$m[id_design]'");
          $ms=mysqli_fetch_array($designa);
          $designan=$koneksi->query("SELECT * FROM jenis_percetakan where id_jenis='$m[id_jenis]'");
          $jenis=mysqli_fetch_array($designan);
                $no++;
                $jmla+=$m['harga']*$m['jumlah'];
                $ps+=$m['jumlah'];
            ?>
                        <tr>
                            <td><input type="hidden" class="form-control"name="id" value="<?= $m['id_pesan'];?>"><?= $no;?></td>
                            <td><?php if($m['jenispesan']=="Costume"){?><img src="images/designpemesanan/<?= $m['gambar'];?>" width="100px" height="100px">
                                <?php }else{ ?> <img  src="images/design/<?= $ms['design'];?>" style="height: 100px;width: 100px;" alt="" /><?php }?></td>
                                <td><?= $m['jenispesan'];?></td>
                            <td><?= $jenis['namajenis'];?></td>
                            <td><?= $m['ukuran'];?><?= $m['satuan'];?></td>
                            <td><?= $m['jumlah'];?></td>
                            <td>Rp. <?= number_format($m['harga'],0,",",".");?></td>
                            <td><?php  echo $m['status']; ?></td>
                            <td><?php  echo $m['keteranganpemesanan']; ?></td>
                             
                            <td>Rp. <?= number_format($m['harga']*$m['jumlah'],0,",",".");?></td>
                             
                            </tr>
                        <?php }?>
                            <tfoot>
                                <tr style="background:#DFF0D8;color:#345;">
                                    <td colspan="4"><B>Total </B></td>
                                    <td><?= $ps;?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><b>Rp. <?= number_format($jmla,0,",",".");?><input type="hidden" name="jum" value="<?= number_format($jmla,0,",",".");?>"></b></td>
                                    
                                </tr>
                               
                               
                               
                            </tfoot>
                        </tbody></table>
                    </form></div></div>
		</div>
	</div>
     <?php

    if (isset ($_POST['simpan'])){
        $file_name = $_FILES['upload']['name'];
        $tmp_name = $_FILES['upload']['tmp_name'];
        $jumlah=addslashes($_POST['jumlah']);
        $jum=addslashes($_POST['jum']);

if($jumlah != $jum){
    echo"<script>alert('Pembayaran Gagal !!! silahkan lakukan pembayaran sesuai dengan total yang anda harus bayar'); window.location = '?page=page/checkout'</script>";
}else{
        $query_simpan =$koneksi->query( "UPDATE pesan SET 
        jumlah='$jumlah',
        status='Proses Cetak',
        ket='Sudah di Bayar' where id_pesan='$_POST[id]'
        ");
        move_uploaded_file($tmp_name, "images/bukti/".$file_name);

$query_simpan =$koneksi->query( "UPDATE pesanpercetakan SET 
        
        status='Proses Cetak',
        ket='Sudah di Bayar' where id_pesan='$_POST[id]'
        ");
    if ($query_simpan) {
        
      echo"<script>alert('Terimakasih atas Pembayaran anda !!!'); window.location = '?page=page/pesanansaya'</script>";
      }else{
      echo"<script>alert('Data  Gagal di Tambah !!!'); window.location = '?page=page/registrasi'</script>";
    }
}
}
?>