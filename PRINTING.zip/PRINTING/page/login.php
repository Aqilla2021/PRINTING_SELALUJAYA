<div class="container">
		<div class="account">
			<h2 class="account-in">Login</h2>
			<?php
if(isset($_POST['login'])){
date_default_timezone_set('Asia/Jakarta');

session_start();

$username = $_POST['username'];
$password = $_POST['password'];
//$password = sha1($password1);

//$username = mysqli_real_escape_string($username);
//$password = mysqli_real_escape_string($password);

if (empty($username) && empty($password)) {
	header('location:index.php?error=Username dan Password Kosong!');
} else if (empty($username)) {
	header('location:index.php?error=Username Kosong!');
} else if (empty($password)) {
	header('location:index.php?error=Password Kosong!');
}

$q = $koneksi->query( "select * from user where username='$username' and password='$password'");
$row = mysqli_fetch_array ($q);

if (mysqli_num_rows($q) == 1) {
    $_SESSION['id']        = $row['id_user'];
    $_SESSION['nama']        = $row['nama'];
    $_SESSION['username']   = $username;
    $_SESSION['password']       = $row['password'];
    $_SESSION['nohp'] = $row['nohp'];
    $_SESSION['foto']     = $row['foto'];
    echo"<script>alert('Login Berhasil !!!'); window.location = '?page=page/home'</script>";
   
	
} else {
 echo"<script>alert('Login Gagal !!!'); window.location = '?page=page/login'</script>";
}
}

?>
				<form method="POST" action="" enctype="multipart/form-data">
					<table>
						
						<tr>
							<td><span class="mail">Username</span></td>
							<td width="400px"><input type="text" name="username" required=""></td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="mail">Password</span></td>
							<td width="400px"><input type="password" name="password" required=""></td>
						</tr>
					</table>
					
					<div class="col-sm-8"><button type="submit" name="login" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>Login</button>
                                        <a  href="?page=page/home"type="button" class="btn btn-danger btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
                                    </div>
				</form>
		</div>
	</div>
