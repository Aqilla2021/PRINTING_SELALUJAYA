<script src="tampilan/jquery.min.js" type="text/javascript"></script>
    <div class="container">
        <div class="account">
            <h2 class="account-in">Pesan Percetakan Costume</h2>
            <?php if(empty($_SESSION['id'])){?> <div class="container">
        <div class="check-out">
            <h4 class="title">Silahkan Login Untuk melakukan Pemesanan !!!</h4>
        </div>

    </div><?php }else{?>
             <?php if(isset($_POST['simpan'])){
              
     $total = $_POST['ttl'];
for($i=1; $i<=$total; $i++)
  {
        $file_name3 = $_FILES["gambar$i"]["name"];
        $tmp_name3 = $_FILES["gambar$i"]["tmp_name"];
        $jumlah = $_POST["jumlah$i"];
        $jenis = $_POST["jenis$i"];
        $ukuran = $_POST["ukuran$i"];
        $keteranganpemesanan = $_POST["keteranganpemesanan$i"];
        $admin=$koneksi->query("SELECT * FROM jenis_percetakan where id_jenis='$jenis' ");
            $m=mysqli_fetch_array($admin);
        $query_simpan=$koneksi->query( "INSERT INTO pesan_temp SET 
            jumlah='$jumlah',
            id_jenis='$jenis',
            ukuran='$ukuran',
            keteranganpemesanan='$keteranganpemesanan',
            satuan='$m[satuan]',
            id_user='$_SESSION[id]',
            jenispesan='Costume',
            status='Baru',
            gambar='$file_name3'");
      move_uploaded_file($tmp_name3, "images/designpemesanan/".$file_name3);
    }

    if ($query_simpan) {
        echo"<script>alert('Pesanan Anda  Berhasil disimpan ke keranjang pemesanan !!!'); window.location = '?page=page/keranjangpesanan'</script>";
      }else{
      echo"<script>alert('Pesanan Anda   Gagal disimpan ke keranjang pemesanan !!!'); window.location = '?page=page/pesanpercetakan'</script>";
    }
}
?>
<div id="angka">
            
               <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                
           <div id="input">
                <table class="table table-bordered table-striped table-sm">
                  
            <tr>
                
                <td><input type='hidden' name='ttl' value='1'>Jenis Percetakan  <select type='text' name='jenis1' class="form-control">
              <option>Pilih</option>
              <?php 
            $no =1;
            $desig=$koneksi->query("SELECT * FROM jenis_percetakan  ");
            while($jen=mysqli_fetch_array($desig)){
                   
          ?> <option value="<?= $jen['id_jenis'];?>"><?= $jen['namajenis'];?> (<?= $jen['harga'];?>/<?= $jen['ukuran'];?><?= $jen['satuan'];?>)</option>
<?php }?>
          </select></td>
                
                <td>Ukuran<input type="text" name="ukuran1" class="form-control" style='background: white; width: 200px;' id="inputku"  placeholder="Panjang X Lebar" required></td>
                <td>Jumlah<input type="text" name="jumlah1" placeholder="input angka" style='background: white; width: 100px;' pattern="[0-9]" class="form-control" required></td>
                
                <td>Keterangan<textarea type='text' name="keteranganpemesanan1" class='form-control' style='background: white; width: 300px;' id="inputku"  placeholder="Keterangan" required></textarea></td>
               
                <td>Foto Design<input type="file" name="gambar1"  required></td>
            </tr>
            
        </table>
                        <div id="insert-form"></div>
                        
                                    <div class="col-sm-8"><button type="submit" name="simpan" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>simpan</button>
                                        
                                        <a  href="?page=page/home"type="button" class="btn btn-danger btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
                                    </div>
                                    
                                
                         </form>
        </div>
        </div><?php }?>
        </div>
    </div>
    <input type="hidden" id="jumlah-form" value="1">
    
    <script>
    $(document).ready(function(){ // Ketika halaman sudah diload dan siap
        $("#btn-tambah-form").click(function(){ // Ketika tombol Tambah Data Form di klik
            var jumlah = parseInt($("#jumlah-form").val()); // Ambil jumlah data form pada textbox jumlah-form
            var nextform = jumlah + 1; // Tambah 1 untuk jumlah form nya
            
            // Kita akan menambahkan form dengan menggunakan append
            // pada sebuah tag div yg kita beri id insert-form
            $("#insert-form").append(
                "<table class='table table-bordered table-striped table-sm'>" +
                "<tr>" +
                " <td><input type='hidden' name='ttl' value='" + nextform + "'>Jenis Percetakan  <select type='text' name='jenis" + nextform + "' class='form-control'> <option>Pilih</option><?php 
                 $desigs=$koneksi->query("SELECT * FROM jenis_percetakan  "); while($jesn=mysqli_fetch_array($desigs)){ ?> <option value='<?php echo $jesn["id_jenis"];?>'><?php echo $jesn["namajenis"];?> (<?php echo $jesn['harga'];?>/<?php echo $jesn['ukuran'];?><?php echo $jesn['satuan'];?>)</option><?php }?></select></td>" +
                "<td>Ukuran<input type='text' name='ukuran" + nextform + "' class='form-control' id='inputku' style='background: white; width: 200px;' placeholder='Panjang X Lebar' required></td><td>Jumlah <input type='text' name='jumlah" + nextform + "' style='background: white; width: 100px;' placeholder='input angka' class='form-control' id='inputku'  onkeydown='return numbersonly(this, event);' onkeyup='javascript:tandaPemisahTitik(this);'required></td>" +
                "<td>Keterangan<textarea type='text' name='keteranganpemesanan" + nextform + "' class='form-control' style='background: white; width: 300px;'   placeholder='Keterangan' required></textarea></td><td>Foto Design<input type='file' name='gambar" + nextform + "' required></td>" +
                "</tr>" +
                "</table>" );
            
            $("#jumlah-form").val(nextform); // Ubah value textbox jumlah-form dengan variabel nextform
        });
        
        // Buat fungsi untuk mereset form ke semula
        $("#btn-reset-form").click(function(){
            $("#insert-form").html(""); // Kita kosongkan isi dari div insert-form
            $("#jumlah-form").val("1"); // Ubah kembali value jumlah form menjadi 1
        });
    });
    </script>
   