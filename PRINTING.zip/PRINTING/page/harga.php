	<div class="container">
		<div class="account">
			<h2 class="account-in">Harga Percetakan</h2>
				<table class="table table-bordered table-striped table-sm" id="example1">
                    <thead>
                        <tr style="background:#DFF0D8;color:#333;">
                            <th>No.</th>
                            <th>Foto</th>
                            <th>Jenis Percetakan</th>
                            <th>Harga</th>
                            <th>Ukuran</th>
                            <th>Satuan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
            $no =0;
            $admin=$koneksi->query("SELECT * FROM jenis_percetakan  ");
            while($m=mysqli_fetch_array($admin)){
            $no++;   
          ?> 
                        <tr>
                            <td><?= $no;?></td>
                            <td><img src="images/jenis/<?= $m['foto'];?>" width="100px" height="100px"></td>
                            <td><?= $m['namajenis'];?></td>
                            <td><?= $m['harga'];?></td>
                            <td><?= $m['ukuran'];?></td>
                            <td><?= $m['satuan'];?></td>
                            </tr><?php }?>
                        </tbody></table>
		</div>
	</div>