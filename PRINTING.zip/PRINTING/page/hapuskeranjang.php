<?php 

     $koneksi->query("DELETE FROM pesan_temp WHERE id_pesantemp='$_GET[id]'");
 echo"<script>alert('Data Berhasil di Hapus !!!'); window.location = '?page=page/keranjangpesanan'</script>";
?>