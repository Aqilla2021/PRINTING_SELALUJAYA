<?php 
          
            if(isset($_POST['id_jenis'])){
IF($_POST['id_jenis']!='Semua'){
            $design=$koneksi->query("SELECT * FROM jenis_percetakan where id_jenis='$_POST[id_jenis]' ");
           $mn=mysqli_fetch_array($design);
       }else{}
   }
                   
          ?> 
          <div class="header">
		
		<div class="header-bottom-in">
		<div class="container">
		<div class="header-bottom-on">
			<p class="wel"><a href="#"><?php 
           
            if(isset($_POST['id_jenis'])){
IF($_POST['id_jenis']!='Semua'){
          echo $mn['namajenis'];
       }else{ echo"Semua Design";
   }
   }else{
   	echo"Semua Design";
   }
                   
          ?></a></p>
			<div class="header-can">
					
					<div class="down-top">	
					<form method="POST" action="">	
						  <select class="form-control" name="id_jenis"onchange='this.form.submit()'>
						  	<?php 
           
            if(isset($_POST['id_jenis'])){
IF($_POST['id_jenis']!='Semua'){
          echo"<option value='$mn[id_jenis]'>$mn[namajenis]</option>";
          echo"<option value='Semua'>Semua</option>";
       }else{ echo"<option value='Semua'>Semua</option>";
   }
   }else{
   	 echo"<option value='Semua'>Semua</option>";
   }
                   
          ?>
							
								  <?php 
						            $no =1;
						            $admin=$koneksi->query("SELECT * FROM jenis_percetakan  ");
						            while($m=mysqli_fetch_array($admin)){
						               if($m['id_jenis']== $mn['id_jenis']){}else{    
						          ?> 
						          <option value="<?= $m['id_jenis'];?>"><?= $m['namajenis'];?></option>
						      	<?php }}?>
							</select>
							<i class="fa fa-filterS"></i>
							<form>
					 </div>
					
					<div class="clearfix"> </div>
			</div>
			<div class="clearfix"></div>
		</div>
		</div>
		</div>
	</div>
          <div class="container">
			<div class="products">
					

						<?php 
            $no =1;
             if(isset($_POST['id_jenis'])){
IF($_POST['id_jenis']!='Semua'){
          $designa=$koneksi->query("SELECT * FROM design as d, jenis_percetakan as j where d.id_jenis=j.id_jenis and d.id_jenis='$mn[id_jenis]'");
       }else{
       	$designa=$koneksi->query("SELECT * FROM design as d, jenis_percetakan as j where d.id_jenis=j.id_jenis ");
       }
   }else{
   	$designa=$koneksi->query("SELECT * FROM design as d, jenis_percetakan as j where d.id_jenis=j.id_jenis ");
   }

            
            while($ms=mysqli_fetch_array($designa)){
                   
          ?> 

						<div class="col-md-3 md-col">
							<br>
							<div class="col-md" style="height:360px;">
								<a href="images/design/<?= $ms['design'];?>" target="_BLANK"><img  src="images/design/<?= $ms['design'];?>" style="height: 250px;width: 240px;" alt="" />

								</a>

								<div class="top-content">
									<h5><a href=""><?= $ms['judul'];?> - <?= $ms['namajenis'];?></a></h5>
									<?php if(isset($_SESSION['id'])){?>
									<div class="white">
										<a href="?page=page/pesanpilih&kat=pilih&id=<?= $ms['id_design']; ?>" class="hvr-shutter-in-vertical hvr-shutter-in-vertical2">Pesan</a>
										<div class="clearfix"></div>
									</div>
								<?php }?>

								</div>							
							</div>
						</div>
<?php } ?>
					<div class="clearfix"></div>
					</div>
					
			</div>
		</div>