<div class="container">
			<div class="contact">
			<h2 class=" contact-in">Kontak Kami</h2>
				
				<div class="col-md-6 contact-top">
					<h3>info Kontak</h3>
					<div class="map">
						<iframe src="<?= $mkon['maps'];?>"></iframe>
					</div>
					
								
					<ul class="social ">
						<li><span><i > </i><?= $mkon['alamat'];?></span></li>
						<li><span><i class="down"> </i><?= $mkon['tlp'];?></span></li>
						<li><a href="mailto:<?= $mkon['email'];?>"><i class="mes"> </i><?= $m['email'];?></a></li>
					</ul>
				</div>
				<div class="col-md-6 contact-top">
					<h3>Keritikan dan Saran</h3>
					<?php

    if (isset ($_POST['simpan'])){
        $kritikan=addslashes($_POST['keritikan']);
        $nama=addslashes($_POST['nama']);
        $email=addslashes($_POST['email']);
        $subjek=addslashes($_POST['subjek']);

        $query_simpan =$koneksi->query( "INSERT INTO keritikandansaran SET 
        nama='$nama',
        email='$email',
        keritikan='$kritikan',
        subjek='$subjek',
        tgl='$tgl_sekarang',
        jam='$jam_sekarang',
        status='Baru'
        ");
      
    if ($query_simpan) {
      echo"<button class='btn btn-success'>Terimakasih atas Keritikan dan Saran Anda !!!!</button>";
      }else{
      echo"<script>alert('Keritikan dan Saran Anda  Gagal di Kirim !!!'); window.location = '?page=page/kontakkami'</script>";
    }}?>
					<form method="POST" action="" enctype="multipart/form-data">
						<div>
							<span>Nama </span>		
							<input type="text" name="nama" >						
						</div>
						<div>
							<span>Email </span>		
							<input type="text" name="email" >						
						</div>
						<div>
							<span>Subject</span>		
							<input type="text" name="subjek">	
						</div>
						<div>
							<span>Keritikan dan Saran</span>		
							<textarea type="text" name="keritikan"> </textarea>	
						</div>
						<input type="submit" name="simpan"value="Kirim" >	
						</form>
				</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	