<script src="tampilan/jquery.min.js" type="text/javascript"></script>
	<div class="container">
		<div class="account">
			<h2 class="account-in">Pesan Percetakan</h2>
             <?php if(isset($_POST['simpan'])){
        $queryy_simpan=$koneksi->query( "INSERT INTO pesan SET 
            status='Baru',
            id_user='$_SESSION[id]',
            tgl='$tgl_sekarang',
            jam='$jam_sekarang'");
         $admin=$koneksi->query("SELECT * FROM pesan where id_user='$_SESSION[id]' and tgl='$tgl_sekarang' and jam='$jam_sekarang'  ");
            $m=mysqli_fetch_array($admin);
     $total = $_POST['ttl'];
for($i=1; $i<=$total; $i++)
  {
        $file_name3 = $_FILES["gambar$i"]["name"];
        $tmp_name3 = $_FILES["gambar$i"]["tmp_name"];
        $jumlah = $_POST["jumlah$i"];
        $jenis = $_POST["jenis$i"];
        $query_simpan=$koneksi->query( "INSERT INTO pesanpercetakan SET 
            jumlah='$jumlah',
            id_jenis='$jenis',
            id_pesan='$m[id_pesan]',
            id_user='$_SESSION[id]',
            tgl='$tgl_sekarang',
            jam='$jam_sekarang',
            status='Baru',
            gambar='$file_name3'");
      move_uploaded_file($tmp_name3, "images/fotodesign/".$file_name3);
    }

    if ($query_simpan) {
    echo'<div class="check-out">
            <h4 class="title">Silahkan checkout untuk melanjutkan pemesanan</h4>
        </div>';
      }else{
     echo'<div class="check-out">
            <h4 class="title">Gagal melakukan pemesanan</h4>
        </div>';
    }}
?><script type="text/javascript" src="js/my.js"></script>
<div id="angka">
            
               <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                
           <div id="input">
				<table class="table table-bordered table-striped table-sm">
                  
            <tr>
                
                <td>Jenis Percetakan  <select type='text' name='jenis1' class="form-control">
              <option>Pilih</option>
              <?php 
            $no =1;
            $desig=$koneksi->query("SELECT * FROM jenis_percetakan  ");
            while($jen=mysqli_fetch_array($desig)){
                   
          ?> <option value="<?= $jen['id_jenis'];?>"><?= $jen['namajenis'];?> (<?= $jen['harga'];?>/<?= $jen['ukuran'];?><?= $jen['satuan'];?>)</option>
<?php }?>
          </select></td>
                
                <td>Jumlah<input type="number" name="jumlah1" class="form-control" id="inputku"  onkeydown="return numbersonly(this, event);" onkeyup="javascript:tandaPemisahTitik(this);" required></td>
                
                
               
                <td>Foto Design<input type="file" name="gambar1"  required></td>
            </tr>
            
        </table>
                        <div id="insert-form"></div>
                        
                                    <div class="col-sm-8"><button type="submit" name="simpan" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>simpan</button>
                                        <button type="button" id="btn-tambah-form" class="btn btn-success btn-flat btn-pri btn-md">Tambah Form</button>
        <button type="button" id="btn-reset-form" class="btn btn-warning btn-flat btn-pri btn-md">Reset Form</button>
                                        <a  href="?page=page/home"type="button" class="btn btn-danger btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
                                    </div>
                                    
                                
                         </form>
		</div>
        </div>
        </div>
	</div>
    <input type="hidden" id="jumlah-form" value="1">
    
    <script>
    $(document).ready(function(){ // Ketika halaman sudah diload dan siap
        $("#btn-tambah-form").click(function(){ // Ketika tombol Tambah Data Form di klik
            var jumlah = parseInt($("#jumlah-form").val()); // Ambil jumlah data form pada textbox jumlah-form
            var nextform = jumlah + 1; // Tambah 1 untuk jumlah form nya
            
            // Kita akan menambahkan form dengan menggunakan append
            // pada sebuah tag div yg kita beri id insert-form
            $("#insert-form").append(
                "<table class='table table-bordered table-striped table-sm'>" +
                "<tr>" +
                " <td><input type='hidden' name='ttl' value='" + nextform + "'>Jenis Percetakan  <select type='text' name='jenis" + nextform + "' class='form-control'> <option>Pilih</option><?php 
                 $desigs=$koneksi->query("SELECT * FROM jenis_percetakan  "); while($jesn=mysqli_fetch_array($desigs)){ ?> <option value='<?php echo $jesn["id_jenis"];?>'><?php echo $jesn["namajenis"];?> (<?php echo $jesn['harga'];?>/<?php echo $jesn['ukuran'];?><?php echo $jesn['satuan'];?>)</option><?php }?></select></td>" +
                "<td>Jumlah <input type='number' name='jumlah" + nextform + "'  class='form-control' id='inputku'  onkeydown='return numbersonly(this, event);' onkeyup='javascript:tandaPemisahTitik(this);'required></td>" +
                "<td>Foto Design<input type='file' name='gambar" + nextform + "' required></td>" +
                "</tr>" +
                "</table>" );
            
            $("#jumlah-form").val(nextform); // Ubah value textbox jumlah-form dengan variabel nextform
        });
        
        // Buat fungsi untuk mereset form ke semula
        $("#btn-reset-form").click(function(){
            $("#insert-form").html(""); // Kita kosongkan isi dari div insert-form
            $("#jumlah-form").val("1"); // Ubah kembali value jumlah form menjadi 1
        });
    });
    </script>
   