<div class="container">
		<div class="account">
			<h2 class="account-in">Registrasi</h2>
			 <?php

    if (isset ($_POST['simpan'])){
        $file_name = $_FILES['foto']['name'];
        $tmp_name = $_FILES['foto']['tmp_name'];
        $nama=addslashes($_POST['nama']);

$nohp = $_POST['nohp'];
        $username=addslashes($_POST['username']);
        $password=addslashes($_POST['password']);
        $nik=addslashes($_POST['nik']);
        $alamat=addslashes($_POST['alamat']);

        $query_simpan =$koneksi->query( "INSERT INTO user SET 
        nama='$nama',
        username='$username',
        nohp='$nohp',
        password='$password',
        nik='$nik',
        alamat='$alamat',
        foto='$file_name'
        ");
        move_uploaded_file($tmp_name, "images/user/".$file_name);


    if ($query_simpan) {
    	
      echo"<script>alert('anda berhasil registerasi !!!'); window.location = '?page=page/login'</script>";
      }else{
      echo"<script>alert('Data  Gagal di Tambah !!!'); window.location = '?page=page/registrasi'</script>";
    }
}?>
				<form method="POST" action="" enctype="multipart/form-data">
					<table>
						<tr>
							<td><span>Nama</span></td>
							<td width="600px"><input type="text" name="nama" required=""></td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="name-in">NIK</span></td>
							<td width="600px"><input type="text" name="nik" required=""></td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="mail">No Hp</span></td>
							<td width="400px"><input type="text" name="nohp" required=""> </td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="mail">Alamat</span></td>
							<td width="400px"><textarea type="text" name="alamat" required=""></textarea>  </td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="mail">Foto</span></td>
							<td width="400px"><input type="file" name="foto" required=""> </td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="mail">Username</span></td>
							<td width="400px"><input type="text" name="username" required=""></td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="mail">Password</span></td>
							<td width="400px"><input type="password" name="password" required=""></td>
						</tr>
					</table>
					
					<div class="col-sm-8"><button type="submit" name="simpan" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>Registrasi</button>
                                        <a  href="?page=page/home"type="button" class="btn btn-danger btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
                                    </div>
				</form>
		</div>
	</div>
