<div class="container">
		<div class="check-out">
    	    <h4 class="title">Tentang Kami</h4>
    	    <p class="cart"><?= $mkon['tentangkami'];?></p>
    	</div>

	</div>