<div class="container">
		<div class="account">
			<h2 class="account-in">Edit Pesan Percetakan Costume</h2>
            <?php $admina=$koneksi->query("SELECT * FROM pesan_temp where id_user='$_SESSION[id]' and  id_pesantemp='$_GET[id]'");
           $edit=mysqli_fetch_array($admina);

$js=$koneksi->query("SELECT * FROM jenis_percetakan where  id_jenis='$edit[id_jenis]'");
           $jenis=mysqli_fetch_array($js);
            if(empty($_SESSION['id'])){?> <div class="container">
        <div class="check-out">
            <h4 class="title">Silahkan Login Untuk melakukan Pemesanan !!!</h4>
        </div>

    </div><?php }else{?>
             <?php if(isset($_POST['simpan'])){
        $id_jenis=addslashes($_POST['id_jenis']);
        $jumlah=addslashes($_POST['jumlah']);
        $ukuran=addslashes($_POST['ukuran']);
        $keteranganpemesanan=addslashes($_POST['keteranganpemesanan']);
        $gambar   = $_FILES['gambar']['name'];
       if (empty($gambar)){
        $query_simpan =$koneksi->query( "UPDATE pesan_temp SET 
       jumlah='$jumlah',
        ukuran='$ukuran',
        keteranganpemesanan='$keteranganpemesanan',
        status='Baru',
        harga='',
        totalharga='',
        id_jenis='$id_jenis' where id_pesantemp='$_GET[id]'
        ");
        

    if ($query_simpan) {
      echo"<script>alert('Pesanan Anda  Berhasil di edit !!!'); window.location = '?page=page/keranjangpesanan'</script>";
      }else{
      echo"<script>alert('Data  Gagal di Edit !!!'); window.location = '?page=page/edicostum&id=$_GET[id]'</script>";
    }
}else{
     $hapus= $koneksi->query("select * from pesan_temp where id_pesantemp='$_GET[id]'");
    $tanggal_gambar=mysqli_fetch_array($hapus,MYSQLI_BOTH);
    $lokasi=$tanggal_gambar['gambar'];
    $hapus_gambar="images/designpemesanan/$lokasi";
    unlink($hapus_gambar);
    move_uploaded_file($_FILES['gambar']['tmp_name'],'images/designpemesanan/'.$gambar);
      $query_simpan =$koneksi->query( "UPDATE pesan_temp SET 
        jumlah='$jumlah',
        ukuran='$ukuran',
        keteranganpemesanan='$keteranganpemesanan',
        status='Baru',
        harga='',
        totalharga='',
        id_jenis='$id_jenis',
        gambar='$gambar' where id_pesantemp='$_GET[id]'
        ");
        

    if ($query_simpan) { 
        echo"<script>alert('Pesanan Anda  Berhasil di edit !!!'); window.location = '?page=page/keranjangpesanan'</script>";
      }else{
      echo"<script>alert('Data  Gagal di Edit !!!'); window.location = '?page=page/edicostum&id=$_GET[id]'</script>";
    }

}
}
?>
<div id="angka"> 
            
               <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                
           <div id="input">
				<table class="table table-bordered table-striped table-sm">
                  <tr>
                      <td>Jenis Percetakan  </td>
                      <td>Ukuran</td>
                      <td>Jumlah</td>
                      <td>Keterangan</td>
                      <td>Foto Design </td>
                  </tr>
            <tr>
                
                <td><input type='hidden' name='ttl' value='1'><select type='text' name='id_jenis' class="form-control">
              <option value="<?= $edit['id_jenis'];?>"><?= $jenis['namajenis'];?> (<?= $jenis['harga'];?>/<?= $jenis['ukuran'];?><?= $jenis['satuan'];?>)</option>
              <?php 
            $no =1;
            $desig=$koneksi->query("SELECT * FROM jenis_percetakan  ");
            while($jen=mysqli_fetch_array($desig)){
                   
          ?> <option value="<?= $jen['id_jenis'];?>"><?= $jen['namajenis'];?> (<?= $jen['harga'];?>/<?= $jen['ukuran'];?><?= $jen['satuan'];?>)</option>
<?php }?>
          </select></td>
                
                <td><input type="text" name="ukuran" class="form-control" style='background: white; width: 200px;' id="inputku"  placeholder="Panjang X Lebar" value="<?= $edit['ukuran'];?>" required></td>
                <td><input type="text" name="jumlah" placeholder="input angka" style='background: white; width: 100px;' pattern="[0-9]" class="form-control" value="<?= $edit['jumlah'];?>" required></td>
                
                <td><textarea type='text' name="keteranganpemesanan" class='form-control' style='background: white; width: 300px;' id="inputku"  placeholder="Keterangan" required><?= $edit['keteranganpemesanan'];?></textarea></td>
                
                
               
                <td><img src="images/designpemesanan/<?= $edit['gambar'];?>"><input type="file" name="gambar"  ></td>
            </tr>
            
        </table>
                        <div id="insert-form"></div>
                        
                                    <div class="col-sm-8"><button type="submit" name="simpan" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>Edit</button>
                                        <a  href="?page=page/pesanansaya"type="button" class="btn btn-danger btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
                                    </div>
                                    
                                
                         </form>
		</div>
        </div><?php }?>
        </div>
	</div>
    <input type="hidden" id="jumlah-form" value="1">
    
    <script>
    $(document).ready(function(){ // Ketika halaman sudah diload dan siap
        $("#btn-tambah-form").click(function(){ // Ketika tombol Tambah Data Form di klik
            var jumlah = parseInt($("#jumlah-form").val()); // Ambil jumlah data form pada textbox jumlah-form
            var nextform = jumlah + 1; // Tambah 1 untuk jumlah form nya
            
            // Kita akan menambahkan form dengan menggunakan append
            // pada sebuah tag div yg kita beri id insert-form
            $("#insert-form").append(
                "<table class='table table-bordered table-striped table-sm'>" +
                "<tr>" +
                " <td><input type='hidden' name='ttl' value='" + nextform + "'>Jenis Percetakan  <select type='text' name='jenis" + nextform + "' class='form-control'> <option>Pilih</option><?php 
                 $desigs=$koneksi->query("SELECT * FROM jenis_percetakan  "); while($jesn=mysqli_fetch_array($desigs)){ ?> <option value='<?php echo $jesn["id_jenis"];?>'><?php echo $jesn["namajenis"];?> (<?php echo $jesn['harga'];?>/<?php echo $jesn['ukuran'];?><?php echo $jesn['satuan'];?>)</option><?php }?></select></td>" +
                "<td>Jumlah <input type='number' name='jumlah" + nextform + "'  class='form-control' id='inputku'  onkeydown='return numbersonly(this, event);' onkeyup='javascript:tandaPemisahTitik(this);'required></td>" +
                "<td>Foto Design<input type='file' name='gambar" + nextform + "' required></td>" +
                "</tr>" +
                "</table>" );
            
            $("#jumlah-form").val(nextform); // Ubah value textbox jumlah-form dengan variabel nextform
        });
        
        // Buat fungsi untuk mereset form ke semula
        $("#btn-reset-form").click(function(){
            $("#insert-form").html(""); // Kita kosongkan isi dari div insert-form
            $("#jumlah-form").val("1"); // Ubah kembali value jumlah form menjadi 1
        });
    });
    </script>
   