<?php $designa=$koneksi->query("SELECT * FROM design as d, jenis_percetakan as j where d.id_jenis=j.id_jenis and d.id_design='$_GET[id]' ");
  

            
            $ms=mysqli_fetch_array($designa);
                   
          ?> <link rel="stylesheet" href="css/etalage.css">
<script src="js/jquery.etalage.min.js"></script>
		<script>
			jQuery(document).ready(function($){

				$('#etalage').etalage({
					thumb_image_width: 300,
					thumb_image_height: 400,
					source_image_width: 900,
					source_image_height: 1200,
					show_hint: true,
					click_callback: function(image_anchor, instance_id){
						alert('Callback example:\nYou clicked on an image with the anchor: "'+image_anchor+'"\n(in Etalage instance: "'+instance_id+'")');
					}
				});

			});
		</script>
<script>$(document).ready(function(c) {
	$('.alert-close').on('click', function(c){
		$('.message').fadeOut('slow', function(c){
	  		$('.message').remove();
		});
	});	  
});
</script>
<script>$(document).ready(function(c) {
	$('.alert-close1').on('click', function(c){
		$('.message1').fadeOut('slow', function(c){
	  		$('.message1').remove();
		});
	});	  
});
</script><div class="container">
			<div class="single">
				<h2 class="account-in">Pesan Percetakan Design Teguh</h2>
            <?php if(empty($_SESSION['id'])){?> <div class="container">
        <div class="check-out">
            <h4 class="title">Silahkan Login Untuk melakukan Pemesanan !!!</h4>
        </div>

    </div><?php }else{?>
				<div class="col-md-9 top-in-single">
					<div class="col-md-5 single-top">	
						<ul id="etalage">
							<li>
								<a href="">
									<img class="etalage_thumb_image img-responsive" src="images/design/<?= $ms['design'];?>" alt="" >
									<img class="etalage_source_image img-responsive" src="images/design/<?= $ms['design'];?>" alt="" >
								</a>
							</li>
							
						</ul>

					</div>	
					<div class="col-md-7 single-top-in">
						<div class="single-para">
							
							<center><h4><?= $ms['judul'];?></h4></center><br>
<form method="POST" action="" enctype="multipart/form-data">
					<table>
						<tr>
							<td><span>Jenis Percetakan</span></td>
							<td width="600px">: <?= $ms['namajenis'];?>
							<input type="hidden" name="id_jenis" value="<?= $ms['id_jenis'];?>">
							<input type="hidden" name="id_design" value="<?= $ms['id_design'];?>">
						</td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="mail">Satuan Ukuran</span></td>
							<td width="400px">: <?= $ms['satuan'];?><input type="hidden" name="satuan" value="<?= $ms['satuan'];?>"></td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="name-in">Ukuran</span></td>
							<td width="600px"> <input type="text" name="ukuran" Placeholder="Panjang X Lebar"  class=" form-control" required=""></td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						<tr>
							<td><span class="name-in">Jumlah</span></td>
							<td width="600px"> <input type="text" name="jumlah" pattern="[0-9]"  class=" form-control" placeholder="Inputkan angka"required=""></td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						
						<tr>
							<td><span class="mail">Keterangan</span></td>
							<td width="400px"><textarea type="text" name="keteranganpemesanan" class="form-control" required=""></textarea>  </td>
						</tr>
						<tr>
							<td><br></td>
							<td></td>
						</tr>
						
						<tr>
							<td><br></td>
							<td><div class="col-sm-8"><button type="submit" name="simpan" class="btn btn-info btn-flat btn-pri btn-md"><i class="fa fa-plus" aria-hidden="true"></i>Kirim</button>
                                        <a  href="?page=page/home"type="button" class="btn btn-danger btn-flat btn-pri btn- d"><i class="fa fa-mail-reply" aria-hidden="true"></i>Batal</a>
                                    </div></td>
						</tr>
						
					</table>
					
					
				</form>
							
							</ul>
						</div>
							
							
						</div>
					</div>
				<div class="clearfix"> </div>
				
				</div>
			<?php if (isset ($_POST['simpan'])){
        $designa=$koneksi->query("SELECT * FROM pesan_temp where id_user='$_SESSION[id]' and id_design='$_POST[id_design]' and ukuran='$_POST[ukuran]'");
  

            
            $ms=mysqli_num_rows($designa);
            if($ms>=1){
echo"<script>alert('Pesanan Anda   Gagal disimpan ke keranjang pemesanan karena design yang ada pilih sudah ada di keranjang pemesanan !!!'); window.location = '?page=page/pesanpilih&id=$_POST[id_design]'</script>";
            }else{



        $id_jenis=addslashes($_POST['id_jenis']);
$keteranganpemesanan = $_POST['keteranganpemesanan'];
        $satuan=addslashes($_POST['satuan']);
        $ukuran=addslashes($_POST['ukuran']);
       $hapus_gambar="../images/admin/$lokasi";
        $query_simpan =$koneksi->query( "INSERT INTO pesan_temp SET 
        id_jenis='$id_jenis',
        id_user='$_SESSION[id]',
        jumlah='$_POST[jumlah]',
        keteranganpemesanan='$keteranganpemesanan',
        ukuran='$ukuran',
        satuan='$satuan',
        status='Baru',
        jenispesan='Design Teguh',
        id_design='$_POST[id_design]'
        ");
        

    if ($query_simpan) {
      echo"<script>alert('Pesanan Anda  Berhasil disimpan ke keranjang pemesanan !!!'); window.location = '?page=page/keranjangpesanan'</script>";
      }else{
      echo"<script>alert('Pesanan Anda   Gagal disimpan ke keranjang pemesanan !!!'); window.location = '?page=page/pesanpilih&id=$_POST[id_design]'</script>";
    }
}
}
 }?>
				
		</div>
		</div>