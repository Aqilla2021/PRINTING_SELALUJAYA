	<div class="container">
		<div class="account">
			<h2 class="account-in">CHECKOUT</h2>
        <div class="check-out">
            <h4 class="title">Silahkan Lakukan Pembayaran Ke No Rekening <b><?= $mkon['norek'];?></b> Bank <b><?= $mkon['bank'];?></b>  Atas Nama  <b><?= $mkon['atasnama'];?></b> Agar Dapat segera Kami Proses</h4>
       </div><div id="angka">
            
               <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                      <div id="input">
				<table class="table table-bordered table-striped table-sm" id="example1">
                    <thead>
                        <tr style="background:#DFF0D8;color:#333;">
                            <th>No.</th>
                            <th>Foto Design</th>
                            <th>Jenis Pesanan</th>
                            <th>Jenis Percetakan</th>
                            <th>Keterangan</th>
                            <th>Ukuran</th>
                            <th>Jumlah</th>
                            <th>Harga</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php  $no=0;
                        $vr=mysqli_num_rows($koneksi->query("select * from pesan_temp where id_user='$_SESSION[id]' and status='Sudah di Verifikasi'"));
                            $admin=$koneksi->query("SELECT * FROM pesan_temp  where id_user='$_SESSION[id]' and status='Sudah di Verifikasi'  ");
            while($m=mysqli_fetch_array($admin)){
                 $designa=$koneksi->query("SELECT * FROM design where id_design='$m[id_design]'");
          $ms=mysqli_fetch_array($designa);
          $designan=$koneksi->query("SELECT * FROM jenis_percetakan where id_jenis='$m[id_jenis]'");
          $jenis=mysqli_fetch_array($designan);
                $no++;
                $jmla+=$m['totalharga'];
            ?>
                        <tr>
                            <td>
                                <input type="hidden" class="form-control"name="id" value="<?= $m['id_pesantemp'];?>"><?= $no;?>
                                <input type="hidden" class="form-control"name="ttl" value="<?= $vr;?>">
                                <input type="hidden" class="form-control"name="id_jenis<?= $no;?>" value="<?= $m['id_jenis'];?>">
                                <input type="hidden" class="form-control"name="id_user<?= $no;?>" value="<?= $m['id_user'];?>">
                                <input type="hidden" class="form-control"name="jumlahpesan<?= $no;?>" value="<?= $m['jumlah'];?>">
                                <input type="hidden" class="form-control"name="ukuran<?= $no;?>" value="<?= $m['ukuran'];?>">
                                <input type="hidden" class="form-control"name="gambar<?= $no;?>" value="<?= $m['gambar'];?>">
                                <input type="hidden" class="form-control"name="harga<?= $no;?>" value="<?= $m['harga'];?>">
                                <input type="hidden" class="form-control"name="keteranganpemesanan<?= $no;?>" value="<?= $m['keteranganpemesanan'];?>">
                                <input type="hidden" class="form-control"name="id_design<?= $no;?>" value="<?= $m['id_design'];?>">
                                <input type="hidden" class="form-control"name="jenispesan<?= $no;?>" value="<?= $m['jenispesan'];?>">
                                <input type="hidden" class="form-control"name="totalharga<?= $no;?>" value="<?= $m['totalharga'];?>">




                        </td>
                             <td><?php if($m['jenispesan']=="Costume"){?><img src="images/designpemesanan/<?= $m['gambar'];?>" width="100px" height="100px">
                                <?php }else{ ?> <img  src="images/design/<?= $ms['design'];?>" style="height: 100px;width: 100px;" alt="" /><?php }?></td>
                                <td><?= $m['jenispesan'];?></td>
                                <td><?= $jenis['namajenis'];?></td>
                            <td><?= $m['keteranganpemesanan'];?></td>
                            <td><?= $m['ukuran'];?><?= $m['satuan'];?></td>
                            <td><?= $m['jumlah'];?></td>
                            <td>Rp. <?= number_format($m['harga'],0,",",".");?></td>
                            <td>Rp. <?= number_format($m['totalharga'],0,",",".");?></td>
                            </tr><?php }?>
                            <tfoot>
                                <tr style="background:#DFF0D8;color:#345;">
                                    <td colspan="8"><B>Total Pembayaran</B></td>
                                    <td><b>Rp. <?= number_format($jmla,0,",",".");?><input type="hidden" name="jum" value="<?= number_format($jmla,0,",",".");?>"></b></td>
                                </tr>
                               
                                <tr style="">
                                    <td colspan="8">Input Jumlah Pembayaran</td>
                                    <td><b>Rp. <input type="text" name="jumlah" id="inputku"  onkeydown="return numbersonly(this, event);" onkeyup="javascript:tandaPemisahTitik(this);" required></b></td>
                                </tr>
                                <tr style="">
                                    <td colspan="8">Upload Bukti Pembayran</td>
                                    <td><b><input type="file" class="form-control"name="upload"required></b></td>
                                </tr>
                               
                            </tfoot>
                        </tbody></table>
                        <div class="check-out">
                        <input type="submit" name="simpan" class="btn btn-success" value="Submit Pembayaran"></div>
                    </form></div></div>
		</div>
	</div>
    <?php if(isset($_POST['simpan'])){
               $file_name = $_FILES['upload']['name'];
        $tmp_name = $_FILES['upload']['tmp_name'];
        $jumlah=addslashes($_POST['jumlah']);
        $jum=addslashes($_POST['jum']);
if($jumlah != $jum){
    echo"<script>alert('Pembayaran Gagal !!! silahkan lakukan pembayaran sesuai dengan total yang anda harus bayar'); window.location = '?page=page/checkout'</script>";
}else{

        $queryy_simpan=$koneksi->query( "INSERT INTO pesan SET 
            
            id_user='$_SESSION[id]',
            tgl='$tgl_sekarang',
            jam='$jam_sekarang',
            jumlah='$jumlah',
        status='Proses Verifikasi',
        ket='Sudah di Bayar',
        upload='$file_name'
        ");
         
        move_uploaded_file($tmp_name, "images/bukti/".$file_name);
         $admin=$koneksi->query("SELECT * FROM pesan where id_user='$_SESSION[id]'  and tgl='$tgl_sekarang' and jam='$jam_sekarang' and status='Proses Verifikasi' ");
            $mas=mysqli_fetch_array($admin);
        
     $total = $_POST['ttl'];
for($i=1; $i<=$total; $i++)
  {
  
        $file_name3 = $_POST["gambar$i"];
        $jumlahpesan = $_POST["jumlahpesan$i"];
        $jenis_id = $_POST["id_jenis$i"];
        $ukuran = $_POST["ukuran$i"];
        $harga = $_POST["harga$i"];
        $keteranganpemesanan = $_POST["keteranganpemesanan$i"];
        $id_design = $_POST["id_design$i"];
        $jenispesan = $_POST["jenispesan$i"];
        $totalharga = $_POST["totalharga$i"];
        $query_simpan=$koneksi->query( "INSERT INTO pesanpercetakan SET 

            id_user='$_SESSION[id]',
            jumlah='$jumlahpesan',
            id_jenis='$jenis_id',
            ukuran='$ukuran',
            harga='$harga',
            keteranganpemesanan='$keteranganpemesanan',
            id_design='$id_design',
            jenispesan='$jenispesan',
            totalharga='$totalharga',
            id_pesan='$mas[id_pesan]',
            tgl='$tgl_sekarang',
            jam='$jam_sekarang',
            status='Proses Verifikasi',
            gambar='$file_name3'");
    }
    $koneksi->query("DELETE FROM pesan_temp WHERE id_user='$_SESSION[id]'");

    if ($query_simpan) {
       echo"<script>alert('Terimakasih atas Pembayaran anda? pesanan anda akan segera kami proses !!!'); window.location = '?page=page/pesanansaya'</script>";
      }else{
       echo"<script>alert('Data Gagal di pesan !!!'); window.location = '?page=page/checkout'</script>";
    }
}
}
    ?>